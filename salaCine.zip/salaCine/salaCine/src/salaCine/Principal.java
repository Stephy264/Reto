package salaCine;

import javax.swing.JOptionPane;

public class Principal {
	
	static Espectador espectador = null; 
	static Pelicula[] peliculas;


	
	public static void main(String[] args) {
		
		int accion = 0; 
	
		do {

			accion = Integer.parseInt(JOptionPane
					.showInputDialog("---   Cine Colombia   --- \n1: Reserva de asientos \n2: Salir del sistema "));
			
			if (accion == 1) {

					cargarPelis();				
					if(reserva(cartelera())) {
						break;
					}
					
			}

		} while (accion < 2);

	}
	
	//reserva de asientos
	public static boolean reserva(int intPelicula) {
		String strNombre = null;
		int intEdad = 0;
		String puestoLetra = null;
		int columna = 0;
		int intDinero = 0;
		String strFilas[] = { "A", "B", "C", "D", "E", "F", "G", "H" }; 
		
		
		Cine cine = new Cine();
		
		while (cine.puestosDisponibles()) {

			strNombre = JOptionPane.showInputDialog("Nombre: ");
			intEdad = Integer.parseInt(JOptionPane.showInputDialog("Edad: "));
			puestoLetra = strFilas[(int) (Math.random() * 8) + 1];
			intDinero = Integer.parseInt(JOptionPane.showInputDialog("Dinero"));
			columna = (int) (Math.random() * 9) + 1;

			espectador = new Espectador(strNombre, intEdad, intDinero, puestoLetra.toUpperCase(), columna);
			
			if(intDinero >= peliculas[intPelicula].getTarifa()) {
				if(intEdad >= peliculas[intPelicula].getEdad()) {
					if(!cine.reserva(espectador)) {
						JOptionPane.showMessageDialog(null, "Asiento no disponoble.");
					}
				}else {
					JOptionPane.showMessageDialog(null, "No cumple con la edad minima para la funci�n.");
				}				
			}else {
				JOptionPane.showMessageDialog(null, "Dinero insuficiente.");
			}
			
			int intOpc = 0;
			intOpc = Integer.parseInt(JOptionPane
					.showInputDialog("---   Cine Colombia   --- \n1: Reserva de asientos \n2: Salir del sistema "));
			
			if(intOpc == 2) {
				break;
			}
			
		}
		return true;
	}
	
	//Cargar Peliculas
	public static void cargarPelis() {
		 
		peliculas =  new Pelicula[4];
		peliculas[0]= new Pelicula("Terminator", 120, 18, "Jose Miel", 10000);		
		peliculas[1] = new Pelicula("Titanic", 120, 25, "Jesucristo Garcia", 7500);
		peliculas[2] = new Pelicula("Cuarto de Guerra", 120, 10, "Ines de Jesus", 12500);
		peliculas[3] = new Pelicula("El peque�o secreto", 120, 10, "Ramiro Otoniel", 5000);
			
	}



	public static int cartelera() {
		return Integer.parseInt(JOptionPane.showInputDialog("Funciones diponibles:\n1. " + peliculas[0].getTitulo() + 
				"\n2. "	+ peliculas[1].getTitulo() + "\n3. " + peliculas[2].getTitulo() + "\n4. " + peliculas[3].getTitulo())) - 1;
		
	}
}
