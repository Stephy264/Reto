package salaCine;

public class Espectador {
	private String nombre;
	private int edad;
	private int dinero;
	private String fila;
	private int columna;

	public Espectador(String nombre, int edad, int dinero, String fila, int columna) {
		this.nombre = nombre;
		this.edad = edad;
		this.dinero = dinero;
		this.columna = columna;
		this.fila = fila; 
	}
		
	public int homologacionColumna(int columna) {
		 int posicion=0;
		switch (columna) {
		case 1:
			posicion =0;
			break;
		case 2:
			posicion =1;
			break;
		case 3:
			posicion =2;
			break;
		case 4:
			posicion =3;
			break;
		case 5:
			posicion =4;
			break;
		case 6:
			posicion =5;
			break;
		case 7:
			posicion =6;
			break;
		case 8:
			posicion =7;
			break;
		case 9:
			posicion =8;
			break;
		default:
			System.out.println("POSICI�N NO SE ENCUENTRA DENTRO DE LA SALA");
			break;
		}
		return posicion;
	}
	
	public int homologacionFilas(String fila) {
		int posicion=0;
		switch (fila) {
		case "A":
			posicion =0;
			break;
		case "B":
			posicion =1;
			break;
		case "C":
			posicion =2;
			break;
		case "D":
			posicion =3;
			break;
		case "E":
			posicion =4;
			break;
		case "F":
			posicion =5;
			break;
		case "G":
			posicion =6;
			break;
		case "H":
			posicion =7;
			break;
		default:
			System.out.println("POSICI�N NO SE ENCUENTRA DENTRO DE LA SALA");
			break;
		}
		return posicion;
	}


	public int getFila() {
		return homologacionFilas(fila);
	}

	public int getColumna() {
		return homologacionColumna(columna);
	}

	public int getEdad() {
		return edad;
	}


}
