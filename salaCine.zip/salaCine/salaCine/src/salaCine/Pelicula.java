package salaCine;

public class Pelicula {
	private String titulo;
	private int duracion;
	private int edad;
	private int tarifa;
	private String director;
	
	public Pelicula(String titulo, int duracion, int edad, String director, int tarifa) {
		this.titulo = titulo;
		this.duracion = duracion;
		this.edad = edad;
		this.director = director;
		this.tarifa = tarifa;
	}
	
	public String getTitulo() {
		return titulo;
	}

	public int getTarifa() {
		return tarifa;
	}

	public int getDuracion() {
		return duracion;
	}

	public int getEdad() {
		return edad;
	}


	public String getDirector() {
		return director;
	}
	
}
