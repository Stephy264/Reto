package salaCine;

import javax.swing.JOptionPane;

public class Cine {

	int cantidadSalas = 4;

	String vecPosicion[] = { "A", "B", "C", "D", "E", "F", "G", "H" };
	private Espectador[][] matSala = new Espectador[8][9];

	public void mostarSalaCine() {

		for (int i = 0; i < matSala.length; i++) {
			for (int j = 0; j <= matSala[0].length; j++) {
				System.out.print(vecPosicion[i] + (j + 1) + " ");
			}
			System.out.println();
		}
	}

	public boolean puestosDisponibles() {
		int intCont = 0;
		System.out.println("   ");
		for (int i = matSala.length - 1; i >= 0 ; i--) {
			for (int j = 0; j < matSala[0].length; j++) {

				if (matSala[i][j] == null) {
					System.out.print(vecPosicion[i] + (j + 1) + " ");
					intCont++;

				} else {
					System.err.print("   ");
				}

			}
			System.out.println();
		}
		if (intCont > 0) {
			return true;
		} else {
			return false;
		}
	}

	public boolean reserva(Espectador espectador) {

		if (matSala[espectador.getFila()][espectador.getColumna()] == null) {
			matSala[espectador.getFila()][espectador.getColumna()] = espectador;
			return true;
		}
		return false;
	}

}
